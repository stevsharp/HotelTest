﻿using ApplicationLayer.Customer;
using ApplicationLayer.Hotel;
using InfrastructureLayer.Data;
using InfrastructureLayer.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HotelProject
{
    public static class ServiceExtensions
    {
        public static void ConfigureSqlContext(this IServiceCollection services, IConfiguration config)
        {
            var connectionString = config["ConnectionStrings:HotelConnectionString"];
            services.AddDbContext<HotelDBContext>(o => o.UseSqlServer(connectionString));
        }

        public static void ConfigureRepository(this IServiceCollection services)
        {
            services.AddScoped<IHotelRepository, HotelRepository>();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
        }

        public static void ConfigureServices(this IServiceCollection services)
        {
            services.AddScoped<IHotelService, HotelService>();
            services.AddScoped<ICustomerService, CustomerService>();
        }
    }
}