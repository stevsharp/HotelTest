﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApplicationLayer.Dto;
using ApplicationLayer.Hotel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelProject.Controllers
{
    [Produces("application/json")]
    [Route("api/Hotel")]
    public class HotelController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IHotelService _hotelService;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hotelService"></param>
        public HotelController(IHotelService hotelService)
        {
            _hotelService = hotelService;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IActionResult DeleteHotel(int id)
        {
            var customer = _hotelService.GetByID(id);
            if (customer == null)
                return NotFound();

            var response =_hotelService.DeleteHotel(id);

            if (!response)
                return StatusCode(500, "Internal server error");

            return NoContent();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hotel"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostCustomer([FromBody] HotelDTO hotel)
        {

            if (!ModelState.IsValid)
                return BadRequest("model not valid");

            var response = _hotelService.CreateHotel(hotel);
            return response ? CreatedAtRoute("DefaultApi", new { Hotel = hotel }, hotel) : StatusCode(500, "Internal server error");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="hotel"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public IActionResult PutHotel(int id, HotelDTO hotel)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var response = _hotelService.UpdateHotel(id, hotel);
            if (!response)
                return StatusCode(500, "Internal server error");

            return NoContent();
        }
    }
}