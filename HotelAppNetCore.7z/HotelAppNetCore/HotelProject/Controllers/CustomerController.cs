﻿using System;
using ApplicationLayer.Customer;
using ApplicationLayer.Dto;
using Microsoft.AspNetCore.Mvc;

namespace HotelProject.Controllers
{
    [Produces("application/json")]
    [Route("api/Customer")]
    public class CustomerController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly ICustomerService _customerService;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerService"></param>
        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var customer = _customerService.GetByID(id);
            if (customer == null)
                return NotFound();

            return Ok(customer);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_customerService.GetAll());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostCustomer([FromBody] CustomerDTO customer)
        {

            if (!ModelState.IsValid)
                return BadRequest("model not valid");

            var response = _customerService.CreateCustomer(customer);
            return response ? CreatedAtRoute("DefaultApi", new { Customer = customer }, customer) : StatusCode(500, "Internal server error");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="customer"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public IActionResult PutCustomer(int id, CustomerDTO customer)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
           
            var response = _customerService.UpdateCustomer(id, customer);
            if (!response)
                return StatusCode(500, "Internal server error");

            return NoContent();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult DeleteCustomer(int id)
        {
            var customer = _customerService.GetByID(id);
            if (customer == null)
                return NotFound();

            var response = _customerService.DeleteCustomer(id);

            if (!response)
                return StatusCode(500, "Internal server error");

            return NoContent();
        }
    }
}