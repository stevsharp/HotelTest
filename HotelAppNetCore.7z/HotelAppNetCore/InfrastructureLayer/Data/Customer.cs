﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfrastructureLayer.Data
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Customer")]
    public partial class Customer
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        public int NumberOfPax { get; set; }

        public int HotelID { get; set; }

        public virtual Hotel Hotel { get; set; }
    }
}
