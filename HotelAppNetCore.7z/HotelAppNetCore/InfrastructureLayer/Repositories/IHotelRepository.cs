﻿using System;
using System.Collections.Generic;
using System.Text;
using InfrastructureLayer.Data;

namespace InfrastructureLayer.Repositories
{
    public interface IHotelRepository : IRepositoryBase<Hotel>
    {
        void CreateHotel(Hotel hotel);
        void UpdateHotel(Hotel hotel);
        void DeleteHotel(int id);
        Hotel Find(int id);
    }

    public class HotelRepository : RepositoryBase<Hotel>, IHotelRepository
    {
        public HotelRepository(HotelDBContext repositoryContext) : base(repositoryContext)
        {
        }

        public void CreateHotel(Hotel hotel)
        {
            Create(hotel);
            Save();
        }

        public void UpdateHotel(Hotel hotel)
        {
            Update(hotel);
            Save();
        }

        public void DeleteHotel(int id)
        {
            var entry = this.Find(id);
            if (entry == null)
                return;

            Delete(entry);
            Save();
        }

        public Hotel Find(int id)
        {
            return this.Find(id);
        }
    }
}
