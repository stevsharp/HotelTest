﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using InfrastructureLayer.Data;

namespace InfrastructureLayer.Repositories
{
    public interface ICustomerRepository : IRepositoryBase<Customer>
    {
        void CreateCustomer(Customer customer);
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(int id);
        Customer Find(int id);
        List<Customer> GetAll();
    }
    /// <summary>
    /// 
    /// </summary>
    public class CustomerRepository : RepositoryBase<Customer>, ICustomerRepository
    {
        public CustomerRepository(HotelDBContext repositoryContext) : base(repositoryContext)
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="customer"></param>
        public void CreateCustomer(Customer customer)
        {
            Create(customer);
            Save();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="customer"></param>
        public void UpdateCustomer(Customer customer)
        {
            Update(customer);
            Save();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        public void DeleteCustomer(int id)
        {
            var entry = this.Find(id);
            if (entry == null)
                return;

            Delete(entry);
            Save();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Customer Find(int id)
        {
            return this.Find(id);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Customer> GetAll()
        {
            return this.GetAll();
        }
    }

}
