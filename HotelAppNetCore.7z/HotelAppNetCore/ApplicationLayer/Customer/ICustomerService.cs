﻿using System.Collections.Generic;
using ApplicationLayer.Dto;

namespace ApplicationLayer.Customer
{
    public interface ICustomerService
    {
        bool CreateCustomer(CustomerDTO customer);

        bool UpdateCustomer(int id, CustomerDTO customer);

        bool DeleteCustomer(int id);

        CustomerDTO GetByID(int id);

        IEnumerable<CustomerDTO> GetAll();
    }
}