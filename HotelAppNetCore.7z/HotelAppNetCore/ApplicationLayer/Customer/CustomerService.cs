﻿using System;
using System.Collections.Generic;
using System.Text;
using ApplicationLayer.Dto;
using InfrastructureLayer.Logging;
using InfrastructureLayer.Repositories;

namespace ApplicationLayer.Customer
{
    public class CustomerService : ICustomerService
    {
        protected readonly CustomerRepository _customerRepository;

        protected readonly ILoggerManager _loggerManager;

        public CustomerService(CustomerRepository customerRepository, ILoggerManager loggerManager)
        {
            _customerRepository = customerRepository;
            _loggerManager = loggerManager;
        }

        public bool CreateCustomer(CustomerDTO customer)
        {
            try
            {
                _customerRepository.CreateCustomer(new InfrastructureLayer.Data.Customer()
                {
                    HotelID = customer.HotelID,
                    LastName = customer.LastName,
                    Name = customer.Name,
                    NumberOfPax = customer.NumberOfPax
                });
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }

        public bool DeleteCustomer(int id)
        {
            try
            {
                _customerRepository.DeleteCustomer(id);
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }

        public IEnumerable<CustomerDTO> GetAll()
        {
            var customers = _customerRepository.GetAll();

            foreach (var customer in customers)
                yield return new CustomerDTO()
                {
                    Name = customer.Name,
                    HotelID = customer.HotelID,
                    NumberOfPax = customer.NumberOfPax,
                    LastName = customer.LastName
                };

        }

        public CustomerDTO GetByID(int id)
        {
            var customer = _customerRepository.Find(id);
            if (customer != null)
            {
                return new CustomerDTO()
                {
                    Name = customer.Name,
                    HotelID = customer.HotelID,
                    NumberOfPax = customer.NumberOfPax,
                    LastName = customer.LastName
                };
            }

            return null;
        }

        public bool UpdateCustomer(int id, CustomerDTO customer)
        {
            try
            {
                var editCustomer = _customerRepository.Find(id);
                if (editCustomer == null)
                    return false;

                editCustomer.HotelID = customer.HotelID;
                editCustomer.Id = id;
                editCustomer.LastName = customer.LastName;
                editCustomer.Name = customer.Name;
                editCustomer.NumberOfPax = customer.NumberOfPax;

                _customerRepository.UpdateCustomer(editCustomer);
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }
    }
}
