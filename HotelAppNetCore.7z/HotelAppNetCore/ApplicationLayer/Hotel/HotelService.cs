﻿using System;
using System.Collections.Generic;
using System.Text;
using ApplicationLayer.Dto;
using InfrastructureLayer.Logging;
using InfrastructureLayer.Repositories;

namespace ApplicationLayer.Hotel
{
    public class HotelService : IHotelService
    {
        protected readonly IHotelRepository _hotelRepository;

        protected readonly ILoggerManager _loggerManager;

        public HotelService(IHotelRepository customerRepository, ILoggerManager loggerManager)
        {
            _hotelRepository = customerRepository;
            _loggerManager = loggerManager;
        }

        public bool CreateHotel(HotelDTO hotel)
        {
            try
            {
                _hotelRepository.CreateHotel(new InfrastructureLayer.Data.Hotel()
                {
                    Name = hotel.Name,
                    Address = hotel.Address,
                    StarRating = hotel.StarRating
                });
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }

        public bool UpdateHotel(int id, HotelDTO hotel)
        {
            try
            {
                var editHotel = _hotelRepository.Find(id);
                if (editHotel == null)
                    return false;

                editHotel.StarRating = hotel.StarRating;
                editHotel.Address = hotel.Address;
                editHotel.Id = id;
                editHotel.Name = hotel.Name;

                _hotelRepository.UpdateHotel(editHotel);
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }

        public bool DeleteHotel(int id)
        {
            try
            {
                _hotelRepository.DeleteHotel(id);
            }
            catch (Exception e)
            {
                _loggerManager.LogError(e.Message);
                return false;
            }

            return true;
        }

        public HotelDTO GetByID(int id)
        {
            var hotel = _hotelRepository.Find(id);
            if (hotel != null)
            {
                return new HotelDTO()
                {
                    StarRating = hotel.StarRating,
                    Name = hotel.Name,
                    Address = hotel.Address
                };
            }

            return null;
        }
    }
}
