﻿using System;
using System.Collections.Generic;
using System.Text;
using ApplicationLayer.Dto;

namespace ApplicationLayer.Hotel
{
    public interface IHotelService
    {
        bool CreateHotel(HotelDTO hotel);
        bool UpdateHotel(int id, HotelDTO hotel);
        bool DeleteHotel(int id);
        HotelDTO GetByID(int id);
    }
}
